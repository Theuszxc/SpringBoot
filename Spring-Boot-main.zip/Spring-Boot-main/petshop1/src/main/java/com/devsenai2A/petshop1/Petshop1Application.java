package com.devsenai2A.petshop1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Petshop1Application {

	public static void main(String[] args) {
		SpringApplication.run(Petshop1Application.class, args);
	}

}
