package com.devsenai2A.petshop1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Petshop1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
